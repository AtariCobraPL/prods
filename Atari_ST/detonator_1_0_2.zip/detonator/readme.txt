DETONATOR
ver. 1.0.2

Atari STE GAME by Cobra & friends
released: Silly Venture 2023 WE
Remake of Atari 8bit game by BQL (1992, Mayonez)

credits:
Mayonez: idea, code, levels, game gfx
ErOs: support
Grey: support
Kaz: tittle screen
Dhor: msx

Party version requirements:
Atari STE, 1 MB RAM

remark:
If you are using a flopy disk and drive to load this game, please leave floppy disk in the drive. Game progress is saved on the disk.



